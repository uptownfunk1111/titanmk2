import os
import pandas as pd
from utilities.load_match_data import load_match_data
from utilities.load_player_stats_custom import load_player_stats_custom as load_player_stats
from utilities.load_detailed_match_data import load_detailed_match_data
from utilities.merge_all import merge_all

# === CONFIGURATION ===
BASE_PATH = "./nrl_fixed"  # Repaired JSONs
OUTPUT_PATH = "./outputs"
YEARS = list(range(2019, 2026))

os.makedirs(OUTPUT_PATH, exist_ok=True)

# === STAGING ===
match_dfs = []
player_dfs = []
detailed_dfs = []

# === PROCESS EACH YEAR ===
for year in YEARS:
    print(f"\n📅 Processing {year}...")
    folder = os.path.join(BASE_PATH, str(year))

    match_file = os.path.join(folder, f"NRL_data_{year}.json")
    player_file = os.path.join(folder, f"NRL_player_statistics_{year}.json")
    detailed_file = os.path.join(folder, f"NRL_detailed_match_data_{year}.json")

    # --- MATCHES ---
    if os.path.exists(match_file):
        match_df = load_match_data(match_file, year)
        print(f"📊 Matches loaded: {len(match_df)}")
        match_dfs.append(match_df)
    else:
        print(f"⚠️  Missing match file: {match_file}")

    # --- PLAYERS ---
    if os.path.exists(player_file):
        player_df = load_player_stats(player_file, year)
        print(f"👥 Player records loaded: {len(player_df)}")
        player_dfs.append(player_df)
    else:
        print(f"⚠️  Missing player stats: {player_file}")

    # --- DETAILED MATCH DATA ---
    if os.path.exists(detailed_file):
        detailed_df = load_detailed_match_data(detailed_file)
        print(f"🧠 Detailed matches loaded: {len(detailed_df)}")
        detailed_dfs.append(detailed_df)
    else:
        print(f"⚠️  Missing detailed data: {detailed_file}")

# === COMBINE ALL DATA ===
print("\n🔗 Merging all data sources...")
match_df_all = pd.concat(match_dfs, ignore_index=True)
player_df_all = pd.concat(player_dfs, ignore_index=True)
detailed_df_all = pd.concat(detailed_dfs, ignore_index=True)

# === FINAL MERGE & FEATURE SET ===
print(f"🔧 Matches: {len(match_df_all)} | Players: {len(player_df_all)} | Details: {len(detailed_df_all)}")
final_df = merge_all(match_df_all, player_df_all, detailed_df_all)

# === EXPORT FILES ===
csv_path = os.path.join(OUTPUT_PATH, "titan_ml_dataset.csv")
json_path = os.path.join(OUTPUT_PATH, "titan_ml_dataset.json")
parquet_path = os.path.join(OUTPUT_PATH, "titan_ml_dataset.parquet")

final_df.to_csv(csv_path, index=False)
final_df.to_json(json_path, orient="records", indent=2)
final_df.to_parquet(parquet_path, index=False)

# === SUMMARY ===
print("\n✅ TITAN 2.5+ Dataset Created:")
print(f"📁 CSV:     {csv_path}")
print(f"📁 JSON:    {json_path}")
print(f"📁 PARQUET: {parquet_path}")
print(f"🧾 Final rows: {len(final_df)} | Columns: {len(final_df.columns)}")
